#!/bin/sh
cd "$(dirname "$0")"
cd ../Resources/bin
exec ./obs "$@"

