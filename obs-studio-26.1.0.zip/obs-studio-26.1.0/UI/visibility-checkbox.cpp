#include "visibility-checkbox.hpp"

VisibilityCheckBox::VisibilityCheckBox() {}

VisibilityCheckBox::VisibilityCheckBox(QWidget *parent) : QCheckBox(parent) {}
