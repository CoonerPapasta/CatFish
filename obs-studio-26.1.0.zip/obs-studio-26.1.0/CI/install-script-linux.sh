#!/bin/sh
set -ex

build_config=RelWithDebInfo
